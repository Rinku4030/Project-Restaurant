package restaurant_management;
import java.sql.*;
import java.util.Scanner;

public class RestaurantApp {

    // Database credentials
    static final String DB_URL = "jdbc:mysql://localhost:3306/restaurant_db";
    static final String USER = "root";
    static final String PASS = "7010@Dshilpitha";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== Restaurant Management ===");
            System.out.println("1. Add Restaurant");
            System.out.println("2. View Restaurants");
            System.out.println("3. Add Menu Item");
            System.out.println("4. View Menu by Restaurant");
            System.out.println("5. Place Order");
            System.out.println("6. View Orders");
            System.out.println("0. Exit");
            System.out.print("Choose: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 : addRestaurant(sc);
                break;
                case 2 : viewRestaurants();
                break;
                case 3 : addMenuItems(sc);
                break;
                case 4 : viewMenu(sc);
                break;
                case 5 : placeOrder(sc);
                break;
                case 6 : viewOrders();
                break;
                case 0 : {
                    System.out.println("Goodbye!");
                    return;
                }
                default : System.out.println("Invalid choice!");
            }
        }
    }

    // === METHODS ===
    private static void addRestaurant(Scanner sc) {
        System.out.print("Enter restaurant name: ");
        String name = sc.nextLine();
        System.out.print("Enter location: ");
        String location = sc.nextLine();

        String sql = "INSERT INTO restaurants (name, location) VALUES (?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, location);
            pstmt.executeUpdate();
            System.out.println("Restaurant added!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewRestaurants() {
        String sql = "SELECT * FROM restaurants";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            System.out.println("=== Restaurants ===");
            while (rs.next()) {
                System.out.println(rs.getInt("restaurant_id") + " | "
                        + rs.getString("name") + " | "
                        + rs.getString("location"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addMenuItems(Scanner sc) {
        System.out.print("Enter restaurant ID: ");
        int rid = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter item name: ");
        String itemName = sc.nextLine();
        System.out.print("Enter price: ");
        double price = sc.nextDouble();

        String sql = "INSERT INTO menu_items (restaurant_id, item_name, price) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, rid);
            pstmt.setString(2, itemName);
            pstmt.setDouble(3, price);
            pstmt.executeUpdate();
            System.out.println(" Menu item added!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewMenu(Scanner sc) {
        System.out.print("Enter restaurant ID: ");
        int rid = sc.nextInt();

        String sql = "SELECT * FROM menu_items WHERE restaurant_id=?";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, rid);
            ResultSet rs = pstmt.executeQuery();
            System.out.println("=== Menu Items ===");
            while (rs.next()) {
                System.out.println(rs.getInt("item_id") + " | "
                        + rs.getString("item_name") + " | $"
                        + rs.getDouble("price"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void placeOrder(Scanner sc) {
        System.out.print("Enter item ID: ");
        int iid = sc.nextInt();
        System.out.print("Enter quantity: ");
        int qty = sc.nextInt();

        String sql = "INSERT INTO orders (item_id, quantity) VALUES (?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, iid);
            pstmt.setInt(2, qty);
            pstmt.executeUpdate();
            System.out.println(" Order placed!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewOrders() {
        String sql = "SELECT o.order_id, m.item_name, o.quantity, o.order_date " +
                     "FROM orders o JOIN menu_items m ON o.item_id = m.item_id";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            System.out.println("=== Orders ===");
            while (rs.next()) {
                System.out.println(rs.getInt("order_id") + " | "
                        + rs.getString("item_name") + " | Qty: "
                        + rs.getInt("quantity") + " | Date: "
                        + rs.getTimestamp("order_date"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}