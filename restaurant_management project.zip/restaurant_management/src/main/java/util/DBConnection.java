package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

	private static final  String url="jdbc:mysql://localhost:3306/restaurant_db";
	private static final  String username	="root"	;
	private static final String password="7010@Dshilpitha";
	
	public static Connection getConnetion() throws SQLException{
		return DriverManager.getConnection(url,username,password);


	}
	public static void main(String[] args) {
	    // Example test code (replace as needed)
	    try {
	        Connection conn = getConnetion();
	        if (conn != null) {
	            System.out.println("Connection Successful");
	        } else {
	            System.out.println("Connection Failed");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
}
