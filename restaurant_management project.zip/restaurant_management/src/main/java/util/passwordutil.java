package util;

import java.security.MessageDigest;

public class passwordutil {
	public static String hashPassword(String password) {
		try {
			MessageDigest ms=MessageDigest.getInstance("SHA-256");
			byte[] hash=ms.digest(password.getBytes());
			StringBuilder hexString=new StringBuilder();
			for(byte b:hash) {
				String hex=Integer.toHexString(0xff & b);
				if(hex.length()==1) hexString.append('0');
				 hexString.append(hex);
					}
			return  hexString.toString();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void main(String[] args) {
		String password="mysecret123";
		String hashed=hashPassword(password);
		System.out.println("Plain:"+password);
		System.out.println("Hashed:"+hashed);

	}
	


}
