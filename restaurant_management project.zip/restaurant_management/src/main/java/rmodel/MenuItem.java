package rmodel;


public class MenuItem {
    private int id;
    private int restaurantId;
    private String name;
    private double price;

    public MenuItem(int id, int restaurantId, String name, double price) {
        this.id = id;
        this.restaurantId = restaurantId;
        this.name = name;
        this.price = price;
    }

    public MenuItem(int restaurantId, String name, double price) {
        this.restaurantId = restaurantId;
        this.name = name;
        this.price = price;
    }

    public int getId() { return id; }
    public int getRestaurantId() { return restaurantId; }
    public String getName() { return name; }
    public double getPrice() { return price; }

    @Override
    public String toString() {
        return id + " | " + name + " | $" + price;
    }
}

	