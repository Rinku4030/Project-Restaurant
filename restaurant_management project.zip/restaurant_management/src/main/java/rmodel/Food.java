package rmodel;

public class Food {
private int id;
private String name;
private String location;
	


public Food(int restaurantid, String restaurantname, String location) {
	super();
	this.id = restaurantid;
	this.name = restaurantname;
	this.location = location;
}

public int getRestaurantid() {
	return id;
}

public void setRestaurantid(int id) {
	this.id = id;
}

public String getRestaurantname() {
	return name;
}

public void setRestaurantname(String name) {
	this.name = name;
}

public String getLocation() {
	return location;
}

public void setLocation(String location) {
	this.location = location;
}

@Override
public String toString() {
	return "Food [id=" + id + ", name=" + name + ", location=" + location + "]";
}

}
