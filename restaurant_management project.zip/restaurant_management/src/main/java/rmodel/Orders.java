package rmodel;


import java.sql.Timestamp;

public class Orders{
    private int id;
    private int itemId;
    private int quantity;
    private Timestamp orderDate;

    public Orders(int id, int itemId, int quantity, Timestamp orderDate) {
        this.id = id;
        this.itemId = itemId;
        this.quantity = quantity;
        this.orderDate = orderDate;
    }

    public Orders(int itemId, int quantity) {
        this.itemId = itemId;
        this.quantity = quantity;
    }

    public int getId() { return id; }
    public int getItemId() { return itemId; }
    public int getQuantity() { return quantity; }
    public Timestamp getOrderDate() { return orderDate; }

    @Override
    public String toString() {
        return id + " | Item ID: " + itemId + " | Qty: " + quantity + " | " + orderDate;
    }
}